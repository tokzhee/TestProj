﻿using NPoco;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AccessBank.LMS.Data.Models
{
  
    public class HmgrStaff
    {
        public long Id { set; get; }
        public string EmployeeNumber { set; get; }

        public string TypeOfLeave { set; get; }
   
        public string EmployeeName { set; get; }
      
      
        public DateTime? StartDate { set; get; }
     
        public DateTime? EndDate { set; get; }
     
        public DateTime? ApprovedDate { set; get; }
    }
}
