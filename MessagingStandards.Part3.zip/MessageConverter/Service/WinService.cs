﻿using Common.Logging;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.DirectoryServices;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Topshelf;
using System.IO;
using System.Xml;
using SWIFTFramework;
using SWIFTFramework.Validation;
using SWIFTFramework.Messages;
using SWIFTFramework.Definition;
//using SwiftMessageParser;

namespace MessageConverter.Service
{
    class WinService
    {
        public ILog Log { get; private set; }
        private readonly object Threading;

        public bool shutdownProcesses = false;


        public WinService(ILog logger)
        {
            Log = logger ?? throw new ArgumentNullException(nameof(logger));
        }
        public bool Start(HostControl hostControl)
        {
            Log.Info($"{nameof(WinService)} Start command received.");





            string mtMessage = File.ReadAllText("C:\\Users\\HP\\Downloads\\SwiftParser-master\\SwiftParser-master\\MessagingStandards\\MTMessages\\MT103Sample.txt");

            //-- SWIFT FRAMEWORK --------------------------------------

            List<ValidationError> parseErrors = new List<ValidationError>();
            SWIFTFramework.SwiftMessage swiftMessage = SWIFTFramework.SwiftParser.Instance.GetMessage(mtMessage,parseErrors);
            SWIFTFramework.SwiftParser parser = SWIFTFramework.SwiftParser.Instance;
            var xmlStr = parser.GetMessageAsXml(swiftMessage);
            //-- END SWIFT FRAMEWORK TEST ------------------------------


            //SwiftMessage message = new SwiftMessage(); message.ParseSwiftMessage(mtMessage.Trim());

            // Console.WriteLine($"Message Type --> {message.Block2.MessageType}");

            // foreach (var block in message.Block4) { Console.WriteLine($"Tag {block.TagName}, Qualifier {block.Qualifier}, Value {block.Value}"); }

            // string mxMessage = ConvertMTtoMX(mtMessage);

            // Now you have the MX message in XML format (mxMessage)
            // Console.WriteLine(mxMessage);
            Console.WriteLine("Done");


            //TODO: Implement your service start routine.
            return true;
        }


        //public static string ConvertMTtoMX(string mtMessage)
        //{
        //    // Parse the MT message using SwiftParser or custom parsing logic
        //    // Replace this with actual parsing logic
        //    //var mtData = ParseMTMessage(mtMessage);

        //    var mtData = SwiftParser.ParseSwiftMessage(mtMessage);
        //    var entries = SwiftParser.ListEntries(mtMessage);
        //    // Map MT data to MX data (replace this with actual mapping logic)
        //    var mxData = MapMTtoMX(mtData);

        //    // Create an MX XML document
        //    var mxDocument = new XmlDocument();

        //    // Create the root element for the MX message ( )
        //    var rootElement = mxDocument.CreateElement("YourMXRoot");
        //    mxDocument.AppendChild(rootElement);

        //    // Populate the MX message with data (replace with actual MX data population)
        //    foreach (var item in mxData)
        //    {
        //        var mxElement = mxDocument.CreateElement(item.Key);
        //        mxElement.InnerText = item.Value;
        //        rootElement.AppendChild(mxElement);
        //    }

        //    // Serialize the MX document to an XML string
        //    string mxXml = mxDocument.OuterXml;

        //    return mxXml;
        //}

        // Replace this with actual MT parsing logic
        private static Dictionary<string, string> ParseMTMessage(string mtMessage)
        {
            // Implement parsing logic to extract data from the MT message
            // Return the parsed data as a dictionary or a structured object
            return new Dictionary<string, string>();
        }


        // Replace this with actual mapping logic
        private static Dictionary<string, string> MapMTtoMX(Dictionary<string, string> mtData)
        {
            // Implement mapping logic to convert MT data to MX data
            // Return the mapped data as a dictionary or a structured object
            return new Dictionary<string, string>();
        }
        public bool Stop(HostControl hostControl)
        {
            shutdownProcesses = true;


            Log.Trace($"{nameof(WinService)} Yes....I am going down gracefully :) ");
            Log.Trace($"{nameof(WinService)} Stop command received.");


            //TODO: Implement your service stop routine.
            return true;

        }
        public bool Pause(HostControl hostControl)
        {

            Log.Trace($"{nameof(WinService)} Pause command received.");

            //TODO: Implement your service start routine.
            return true;

        }
        public bool Continue(HostControl hostControl)
        {

            Log.Trace($"{nameof(WinService)} Continue command received.");

            //TODO: Implement your service stop routine.
            return true;

        }
        public bool Shutdown(HostControl hostControl)
        {

            Log.Trace($"{nameof(WinService)} Shutdown command received.");

            //TODO: Implement your service stop routine.
            return true;

        }

    }
}
