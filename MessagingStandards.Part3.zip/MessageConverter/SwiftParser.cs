﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace MessageConverter.Service.SwiftParser
{
    class SwiftParser
    {
        public static Dictionary<string, string> ParseSwiftMessage(string swiftMessage)
        {
            var result = new Dictionary<string, string>();

            // Split the message into lines
            string[] lines = swiftMessage.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);

            foreach (string line in lines)
            {
                // Use regular expressions to match SWIFT tag and data pairs
                //Match match = Regex.Match(line, @":(\w{2}):(.+)");
                Match match = Regex.Match(line, @"(?<key>[^:]+):(?<value>[^,]+),?");
                if (match.Success)
                {
                    string tag = match.Groups[1].Value;
                    string value = match.Groups[2].Value;

                    // Store the tag and its value in the result dictionary
                    result[tag] = value;
                }
            }

            return result;
        }

        public static Dictionary<string, string> ParseMTMessage(string mtMessage)
        {
            var result = new Dictionary<string, string>();

            // Define regular expressions to match specific SWIFT fields
            var field20Regex = new Regex(@":20:(?<Value>.+)");
            var field32ARegex = new Regex(@":32A:(?<Value>\d{6})");
            var field50KRegex = new Regex(@":50K:(?<Value>.+)");
            var field72Regex = new Regex(@":72:(?<Value>.+)");

            // Define a regular expression pattern to match all fields
            var fieldRegex = new Regex(@":(\d+[A-Z]?):(?<Value>.+)");

            // Split the message into lines
            string[] lines = mtMessage.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);

            foreach (string line in lines)
            {
                Match match = fieldRegex.Match(line);
                if (match.Success)
                {
                    string tag = match.Groups[1].Value;
                    string value = match.Groups["Value"].Value;

                    // Store the tag and its value in the result dictionary
                    result[tag] = value;
                }
            }

            return result;
        }

        public  static List<string> ListEntries(string swiftMessage)
        {
            //string swiftMessage = File.ReadAllText("SwiftMessage.txt");
            var entries = new List<String>(); 
            Dictionary<string, string> parsedData = ParseMTMessage(swiftMessage);

            // Access and use the parsed data as needed
            foreach (var kvp in parsedData)
            {
                 Console.WriteLine($"{kvp.Key}: {kvp.Value}");
                entries.Add($"{kvp.Key}: {kvp.Value}");
            }
            return entries;
        }
    }

}


